import React, {Component} from 'react';
import {LogBox, ScrollView, View} from 'react-native'
import Container from "../components/Container";
import CustomText from "../components/CustomText";
import {heightPercentageToDP as hp, widthPercentageToDP as wp} from 'react-native-responsive-screen';
import DairyList from "../components/DairyList";
import {Spacing} from "../styles/Global";
import If from "../components/If";
import Icons from "react-native-vector-icons/Ionicons"
import { FloatingAction } from "react-native-floating-action";
import ReactNativeModal from 'react-native-modal';
import CreateOrEditDairyItem from "../components/Modal/CreateOrEditDairyItem";
import { ActionSheetCustom as ActionSheet } from 'react-native-actionsheet'
import {DairyItem} from "../models/DairyItem";
import {ScreenNames} from "../utils/navigation/Routes";
import Reactotron from 'reactotron-react-native'
import {connect} from 'react-redux'
import {DairyActions} from "../redux/actions/DairyActions";
import {rootReducerState} from "../redux/reducers";
import {Repository} from "../services/Repository";

interface Props {
    route: any;
    navigation: any;
    dairyItems: DairyItem[];
    onDelete: any;
    getDairyItems: any;
    dairyItemsLoading: boolean;
    dairyItemsLoaded: boolean;
}

interface State {
    selectedItem: DairyItem;
}

enum ActionTypes {
    VIEW = 0,
    EDIT = 1 ,
    DELETE = 2,
    CANCEL = 3

}

// Redux Start
class Dashboard extends React.Component<Props, State> {
    private actionSheetRef: any;


    constructor(props){
        super(props);
        this.state={
            selectedItem: null
        };
    }

    componentDidMount(): void {
        this.fetchData();
        console.log('-----------Navigation Details------------');
        console.log(this.props.navigation);
        console.log('-----------Route Details------------');
        console.log(this.props.route);
    };

    fetchData(force = false){
        this.props.getDairyItems({
            loading: this.props.dairyItemsLoading,
            loaded: this.props.dairyItemsLoaded,
        }, force)
    }


    actions =[
        {
            text: "Accessibility",
            name: "bt_accessibility",
            icon: <Icons style={{alignSelf:'center'}} color={'white'} name={'add'} size={30}></Icons>,
            position: 1
        },
    ];

    handleActionButton=index=>
    {

        switch (index) {
            case ActionTypes.CANCEL:{
                this.setState({selectedItem: null});
                break;
            }
            case ActionTypes.EDIT:{
                this.onAddOrUpdate();
                break;
            }
            case ActionTypes.VIEW:{
                this.onView();
                break;
            }
            case ActionTypes.DELETE:{
                this.onDelete();
                break;
            }
        }
    };

    onAddOrUpdate(){
        this.props.navigation.navigate(ScreenNames.EDIT_ADD_DAIRY_ITEM,
            {dairyItem: this.state.selectedItem});
        this.setState({selectedItem: null});
    }

    onView = () =>{
        this.props.navigation.navigate(ScreenNames.VIEW_DAIRY_ITEM,
            {dairyItem: this.state.selectedItem});
        this.setState({selectedItem: null});
    };

    onDelete(){
        this.props.onDelete(this.state.selectedItem.id);
        this.setState({selectedItem: null});
    }




    render() {
       // Reactotron.log(this.props.dairyItems);
      //  console.log('Dashboard is render again');
        return (
            <Container containerStyle={{justifyContent:'flex-start'}}>

                <If show={!!this.props.dairyItems.length}>
                        <DairyList onPress={(val)=>{
                            this.setState({
                                selectedItem: val
                            });
                            this.actionSheetRef.show();
                        }} dairyItems={this.props.dairyItems}/>
                </If>


                  <If show={!this.props.dairyItems.length}>
                      <Container containerStyle={{alignItems:'center'}}>
                          <View style={{marginBottom: 60}}>
                              <Icons style={{alignSelf:'center'}} name={'information-circle-outline'} size={50}></Icons>
                              <CustomText style={{width: wp('90%'), textAlign:'center'}}>
                                  Currently, No content found. Please start content item.
                              </CustomText>
                          </View>
                      </Container>
                  </If>

                <FloatingAction
                    actions={this.actions}
                    onPressItem={name => {
                        this.onAddOrUpdate();
                    }}
                />



                    <ActionSheet
                        ref={ref => this.actionSheetRef = ref}
                        title={<CustomText>'Which one do you like ?'</CustomText>}
                        options={['View', 'Edit', 'Delete', 'Cancel']}
                        destructiveButtonIndex={2}
                        cancelButtonIndex={3}
                        onPress={this.handleActionButton}

                        //  onPress={(index) => {
                        //      console.log(index, this.state.selectedItem);
                        //  }}
                    />




            </Container>
        );
    }

}

const mapStateToProps = (state:rootReducerState) => ({
        dairyItems: state.dairyReducer.dairyItems,
        dairyItemsLoading: state.dairyReducer.loading,
        dairyItemsLoaded: state.dairyReducer.loaded,

});


const mapDispatchToProps = dispatch => ({
        onDelete : (id) => dispatch(DairyActions.deleteDairyItemAction(id)),
        getDairyItems: (status, force)=>dispatch(Repository.getDairyItems(status, force))

});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);

