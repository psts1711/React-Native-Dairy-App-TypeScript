import React, {Component} from 'react';
import Container from "../components/Container";
import {KeyboardAvoidingView, StyleSheet, TextInput, ToastAndroid, View} from "react-native";
import {FloatingAction} from "react-native-floating-action";
import {widthPercentageToDP as wp} from "react-native-responsive-screen";
import {DairyItem} from "../models/DairyItem";
import Icons from "react-native-vector-icons/Ionicons"
import {DairyActions} from "../redux/actions/DairyActions";
import {connect} from 'react-redux'
import DateTimePicker from "react-native-modal-datetime-picker";
import DateNTime from "../components/DateNTime";
import ImageGallery from '../components/Modal/ImageGallery'
import ImageCropPicker from 'react-native-image-crop-picker';
import {Repository} from "../services/Repository";

interface Props {
    route: {params: {dairyItem: DairyItem}};
    onAdd: any;
    onUpdate: any;
    navigation: any;

}

interface State {
    subjectTextInput: string;
    dairyTextInput: string;
    timestamp: Date;
    isDateTimePickerVisible: boolean;
    isImageGalleryVisible: boolean;
    images: any[];
}

enum ActionTypes{
    DATE_PICKER = 'datePicker',
    ADD = 'add',
    IMAGE_PICKER = 'imagePicker'
}

class EditOrAddItem extends Component<Props, State> {
    private  readonly  dairyItem = this.props.route.params.dairyItem;

    constructor(props) {
        super(props);
        this.state = {
            subjectTextInput: this.dairyItem ? this.dairyItem.subject : '',
            dairyTextInput: this.dairyItem ? this.dairyItem.description : '',
            timestamp: this.dairyItem ? this.dairyItem.timestamp : new Date(),
            isDateTimePickerVisible: false,
            isImageGalleryVisible: false,
            images: []
        }
    }

    updateSubjectTextInput = (val) => {
        this.setState({
            subjectTextInput: val
        });
    };

    updateDairyTextInput = (val) => {
        this.setState({
            dairyTextInput: val
        })
    };

    actions = [
        {
            text: this.dairyItem ? 'Update':'Add',
            name: 'add',
            icon: <Icons style={{alignSelf:'center'}} color={'white'} name={'checkmark'} size={20}></Icons>,
            position: 1
        },
        {
            text: 'Pick Date and Time',
            name: 'datePicker',
            icon: <Icons style={{alignSelf:'center'}} color={'white'} name={'calendar-sharp'} size={20}></Icons>,
            position: 2
        },
        {
            text: 'Add Image',
            name: 'imagePicker',
            icon: <Icons style={{alignSelf:'center'}} color={'white'} name={'images-outline'} size={20}></Icons>,
            position: 3
        },
    ];

    onSaveOrUpdate = () => {
        if(this.dairyItem){
            const data: DairyItem = {...this.dairyItem,
                subject: this.state.subjectTextInput,
                description: this.state.dairyTextInput,
                timestamp: this.state.timestamp,
                images: this.state.images,
            };
            this.props.onUpdate(data);
            this.props.navigation.pop();
        }else{
            const data: DairyItem = {
                subject: this.state.subjectTextInput,
                description: this.state.dairyTextInput,
                // id: Date.now() + Math.random(),
                images: this.state.images,
                timestamp: this.state.timestamp
            };
            this.props.onAdd(data);
            this.props.navigation.pop();
        }
    };

    dateTimePickedHandle = (date) => {
        console.log(date);
        this.setState({
            timestamp: date,
            isDateTimePickerVisible: false
        })
    };

    onActionPress=(val)=>{
       // console.log(val);
        /*if(val===ActionTypes.ADD){
            this.onSaveOrUpdate();
        }else if(val===ActionTypes.DATE_PICKER){
            this.setState({
                isDateTimePickerVisible: true
            })
        }*/

        switch (val) {
            case ActionTypes.ADD:{
                this.onSaveOrUpdate();
                break;
            }
            case ActionTypes.DATE_PICKER:{
                this.setState({
                    isDateTimePickerVisible: true
                });
                break;
            }
            case ActionTypes.IMAGE_PICKER:{
               // console.log('call image');
                this.setState({isImageGalleryVisible: true});
                break;
            }
        }
    };

    onImageSelect= async ()=>{
       try {
           const images:any = await  ImageCropPicker.openPicker({
               multiple: true,
               maxFiles: 5
           });

          // console.tron.log(images);

            // get only path using map
           const imagesPath = images.map(data=>data.path);
          // console.tron.log(imagesPath);

           this.setState({
               images: this.state.images.concat(imagesPath)
           })
       }catch (e) {
           ToastAndroid.show(e.message, ToastAndroid.LONG);
       }
    };

    onImageDelete = (val) => {
       // console.log(val);
        const filterArray = this.state.images.filter(image=>image != val);
      //  console.log(filterArray);

        this.setState({
            images: filterArray
        });

    };


    render() {
      //  console.log(this.props.route);
        return (
            <Container>
                <View>
                    <TextInput value={this.state.subjectTextInput}
                               allowFontScaling={false}
                               onChangeText={this.updateSubjectTextInput}
                               style={[styles.textInput, {borderBottomWidth:1, borderTopWidth:1}]}
                               placeholder={'Enter Subject'}/>

                               <DateNTime containerStyle={{padding:10}}
                                          timestamp={this.state.timestamp}/>
                    <KeyboardAvoidingView>
                        <TextInput value={this.state.dairyTextInput}
                                   allowFontScaling={false}
                                   onChangeText={this.updateDairyTextInput}
                                   multiline={true}
                                   scrollEnabled={true}
                                   style={[styles.textInput, {borderBottomWidth:1}]}
                                   placeholder={'Write here your notes or dairy...'}/>
                    </KeyboardAvoidingView>
                </View>

                <FloatingAction
                    actions={this.actions}
                    onPressItem={this.onActionPress}

                   /* onPressItem={(val)=>{
                        console.log(val);
                    }}*/
                    // onPressItem={this.onSaveOrUpdate}
                />

                <DateTimePicker mode={'datetime'}
                                is24Hour={false}
                                isVisible={this.state.isDateTimePickerVisible}
                                onConfirm={this.dateTimePickedHandle}
                                onCancel={()=>this.setState({
                                    isDateTimePickerVisible: false
                                })} />
                 <ImageGallery onImageDelete={this.onImageDelete}
                     onImageSelect={this.onImageSelect}
                     images={this.state.images}
                     isVisible={this.state.isImageGalleryVisible}
                     onDismiss={()=>this.setState({
                                   isImageGalleryVisible: false
                               })}/>
            </Container>
        );
    }

    componentDidMount(): void {
    }
}

const styles = StyleSheet.create({
    textInput:{
        width:wp('100%')
    }
});

const dispatchToProps = dispatch => ({
        onAdd: (dairyItem: DairyItem) =>
            dispatch(Repository.addDairyItem(dairyItem)),
            //dispatch(DairyActions.addDairyItemAction(dairyItem)),

        onUpdate: (dairyItem: DairyItem) =>
            dispatch(DairyActions.updateDairyItemAction(dairyItem)),
});

export default connect(null, dispatchToProps)(EditOrAddItem);