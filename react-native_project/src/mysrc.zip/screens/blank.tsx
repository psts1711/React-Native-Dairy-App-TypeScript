import React, {Component} from 'react';
import {View} from 'react-native'
import Container from "../components/Container";

interface Props {
}

interface State {
}

class blank extends React.Component<Props, State> {
    constructor(props){
        super(props);
        this.state={};
    }
    render() {
        return (
            <Container>
                <View/>
            </Container>
        );
    }

    componentDidMount(): void {
    }
}

export default blank;