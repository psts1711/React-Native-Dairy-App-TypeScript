import React, {Component} from 'react';
import Container from "../components/Container";
import {Image, ScrollView, View} from "react-native";
import CustomText from "../components/CustomText";
import {Spacing} from "../styles/Global";
import {PrimaryTheme} from "../styles/Themes";
import DateNTime from "../components/DateNTime";
import Carousel from 'react-native-snap-carousel';
import {DairyItem} from "../models/DairyItem";
import {widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Lightbox from 'react-native-lightbox';

interface Props {
    route: any
}

interface State {

}

class ViewDairyItem extends Component<Props, State> {
    private readonly dairyItem : DairyItem = this.props.route.params.dairyItem;

    constructor(props) {
        super(props);
        this.state = {}
    }

    renderItem=(data)=>{
        return <Lightbox >
            <Image style={{height: hp('35%'),
                width: wp('100%')}} source={{uri:data.item}} />
            </Lightbox>

    };

    render() {
       // console.log(this.props.route);
        return (
            <Container
                containerStyle={{justifyContent:'flex-start'}}>

                <ScrollView>
                  <View style={{padding:5}}>

                         <Carousel
                             containerCustomStyle={{alignSelf:'center', height: 'auto'}}
                             sliderWidth={wp('98%')}
                             itemWidth={wp('98%')}
                             autoplay={true}
                             data={this.dairyItem.images}
                             renderItem={this.renderItem}
                         />
                         <View style={{padding:10}}>
                             <DateNTime timestamp={this.dairyItem.timestamp}/>
                             <CustomText style={{marginBottom:
                                 Spacing.large.marginBottom, color: PrimaryTheme.$ACCENT_COLOR}}>
                                 {this.dairyItem.subject}
                             </CustomText>

                             <CustomText>
                                 {this.dairyItem.description}
                             </CustomText>
                         </View>
                  </View>
                </ScrollView>

            </Container>
        );
    }

    componentDidMount(): void {
    }
}


export default ViewDairyItem;