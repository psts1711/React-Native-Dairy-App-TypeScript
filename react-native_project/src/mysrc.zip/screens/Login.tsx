import * as React from 'react';
import {
    View,
    TextInput,
    Text,
    SafeAreaView,
    StyleSheet,
    Button,
    Dimensions,
    Platform,
    ScrollView,
    ActivityIndicator
} from 'react-native';
import {Formik} from 'formik';
import {widthPercentageToDP as wp, heightPercentageToDP as hp, listenOrientationChange , removeOrientationListener} from 'react-native-responsive-screen';
import Icons from "react-native-vector-icons/Ionicons"
import Container from "../components/Container";
import CustomText from "../components/CustomText";
import {lComponentStyle, pComponentStyle, Typography} from "../styles/Global";
import {Validators} from "../utils/validators";
import {Utils} from "../utils/Utils";
import If from "../components/If";
import CustomButton from "../components/CustomButton";
import {Api} from "../services/Api";
import {connect} from 'react-redux'
import {AuthRepository} from "../services/AuthRepository";
import {rootReducerState} from "../redux/reducers";

interface State {
    form:{
        emailTextInput: string,
        passwordTextInput: string
    };
    orientation: string;
}

interface Props {
    login: any;
    loggingIn: boolean;
}

 class Login extends React.Component<Props, State>{
    private passwordInputRef;
    constructor(props){
        super(props);
        this.state={
            form:{
                emailTextInput: '',
                passwordTextInput: '',
            },
            orientation: 'potrait'
        };
    };

    componentDidMount(): void {
        listenOrientationChange(this);
    };
    componentWillUnmount(): void {
        removeOrientationListener();
    };

     onLogin = (value) => {
        // console.log(value);
         this.props.login({
             email: value.emailTextInput,
             password: value.passwordTextInput,
             returnSecureToken: true
         })
     };

    render(){
        return (
            <Container containerStyle={{alignItems:'center'}}>

                    <Icons name={'lock-closed-outline'} size={50}></Icons>

                    <CustomText style={ [Typography.title, {letterSpacing:2, marginBottom: hp('3%')}] /*pComponentStyle.pageTitle*/ }>Login</CustomText>

                    <Formik
                        initialValues={this.state.form}
                        validateOnMount={true}
                        validateOnChange={true}
                        onSubmit={value => this.onLogin(value)}
                        validationSchema={Validators.loginValidator}>
                        {props=>{
                            return (
                                <View style={{alignItems:'center'}}>
                                    <TextInput onSubmitEditing={()=>this.passwordInputRef.focus()}
                                               returnKeyType={'next'}
                                               onChangeText={props.handleChange('emailTextInput')}
                                               onBlur={()=>props.setFieldTouched('emailTextInput')}
                                               style={Utils.dynamicStyles(pComponentStyle.textInput, lComponentStyle.textInput, this.state.orientation)}
                                               placeholder={'Email'}
                                              // keyboardType={'phone-pad'}
                                               value={props.values.emailTextInput} />

                                    <If show={props.dirty && props.touched.emailTextInput}>
                                        <CustomText style={[Typography.error]}>{props.errors.emailTextInput}</CustomText>
                                    </If>

                                    <TextInput
                                        onSubmitEditing={()=>{
                                            if(props.isValid){
                                                console.log('is valid')
                                            }else{
                                                console.log('form is not valid')
                                            }
                                        }}
                                        ref={ref=>this.passwordInputRef = ref}
                                        returnKeyType={'go'}
                                        onChangeText={props.handleChange('passwordTextInput')}
                                        onBlur={()=>props.setFieldTouched('passwordTextInput')}
                                        secureTextEntry={true}
                                        style={this.state.orientation==='potrait'?pComponentStyle.textInput : lComponentStyle.textInput}
                                        placeholder={'Password'}
                                        value={props.values.passwordTextInput} />

                                    <If show={props.dirty && props.touched.passwordTextInput}>
                                        <CustomText style={[Typography.error]}>{props.errors.passwordTextInput}</CustomText>
                                    </If>


                                    <CustomButton useIcon={true}
                                                  iconName={'arrow-forward-circle-outline'}
                                                  iconSize={32} iconColor={'white'}
                                                  disabled={!props.isValid} onPress={()=>{
                                        if(props.isValid){
                                            return props.handleSubmit();
                                        }else{
                                        }
                                    }} title={'Login'} />

                                    <If show={this.props.loggingIn}>
                                        <ActivityIndicator size={'large'} />
                                    </If>

                                </View>
                            )
                        }}
                    </Formik>

            </Container>

        )
    }
}

const potraitStyle = () => {
    return StyleSheet.create({

    })
};

const landScapeStyle = () => {
    return StyleSheet.create({

    })
};

const mapStateToProps=(state:rootReducerState)=>({
    loggingIn: state.userReducer.loggingIn
});

const mapDispatchToProps=dispatch=>({
    login: data=>dispatch(AuthRepository.login(data))

});

export default connect(mapStateToProps, mapDispatchToProps)(Login);