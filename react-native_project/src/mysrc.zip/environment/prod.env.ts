import {Environment} from "./index";

export const ProdEnvironment : Environment = {
    base_api_url: 'https://react-native-course-49211-default-rtdb.firebaseio.com/',
    auth_url: 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDgWlUlxckuBPsKLh2sayz4uyxJLG3yT64'
};