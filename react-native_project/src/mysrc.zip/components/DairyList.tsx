import * as React from 'react';
import {FlatList, ListRenderItemInfo, View} from 'react-native'
import DairyItem from "./DairyItem";
import {Spacing} from "../styles/Global";
import {DairyItem as dairyItem} from "../models/DairyItem";

export interface Props {
   dairyItems: dairyItem[];
   onPress: any;
}

const DairyList = (props: Props) =>{
    return (
        <FlatList style={{marginTop: Spacing.extralarge.marginTop}} showsVerticalScrollIndicator={false}
                  maxToRenderPerBatch={10}
                  keyExtractor={(item, index)=>index.toString()}
                  data={props.dairyItems}
                  extraData={props}
                  renderItem={(data)=>{
           // console.log(data)
            return(<DairyItem onPress={()=>props.onPress(data.item)} dairyItem={data.item}/>)
        }} />
    )
}

export default DairyList;

{/*
<>
    {props.dairyItems.map((dairyItem:{subject: string, description:string}, index: number)=>{
        return (
            <DairyItem dairyItem={dairyItem} key={index} index={index}/>
        )
    })}
</>*/}
