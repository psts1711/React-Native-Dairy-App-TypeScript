import * as React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, ViewStyle, TextStyle} from 'react-native';
import {PrimaryTheme} from "../styles/Themes";
import CustomText from "./CustomText";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

import If from "./If";
import Icon from "./Icon";

export interface Props {
    title: string;
    disabled?: boolean;
    buttonStyle?: ViewStyle | ViewStyle[];
    textStyle?: any;
    onPress: any;
    useIcon?: boolean;
    iconName?: string;
    iconSize?:number;
    iconColor?:string;
}

const CustomButton = (props: Props) =>{
    return <TouchableOpacity onPress={props.onPress}
                             style={[props.disabled?{...styles.buttonSyle,
                                 backgroundColor:PrimaryTheme.$DIVIDER_COLOR} :
                                 styles.buttonSyle, props.buttonStyle]}
                             disabled={props.disabled}>
        <If show={props.useIcon}>
            <Icon name={props.iconName} size={props.iconSize} color={props.iconColor} />
        </If>

        <CustomText style={[styles.textSyle, props.textStyle]}>{props.title}</CustomText>
    </TouchableOpacity>
}

const styles = StyleSheet.create({
    buttonSyle:{
        backgroundColor: PrimaryTheme.$DARK_PRIMARY_COLOR,
        borderRadius: 4,
        width: wp('30'),
        height: hp('6.5'),
        flexDirection: "row",
        justifyContent:'center',
        alignItems:'center'
       // alignSelf: 'center'
    },
    textSyle:{
        color:'white',
        textAlign:'center',
        fontWeight: 'bold',
        fontSize: 18,
        padding: 7
    }
})

CustomButton.defaultProps = {
    disabled: false,
    useIcon: false,
    iconSize: 35,
    iconColor: 'orange'
};

export default CustomButton;