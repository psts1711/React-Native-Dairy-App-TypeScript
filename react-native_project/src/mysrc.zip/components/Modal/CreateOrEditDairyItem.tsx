import React, {Component} from 'react';
import {TextInput, View, StyleSheet, KeyboardAvoidingView, ToastAndroid} from 'react-native'
import ReactNativeModal from "react-native-modal";
import CustomText from "../CustomText";
import Container from "../Container";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from "react-native-responsive-screen";
import {FloatingAction} from "react-native-floating-action";
import Icons from "react-native-vector-icons/Ionicons"
import {DairyItem} from "../../models/DairyItem";

interface Props {
    isVisible: boolean;
    onDismiss: any;
    onSave: any;
    dairyItem?:DairyItem;
    onUpdate: any;
}

const CreateOrEditDairyItem = (props: Props)=>{

    // hooks
    const [subjectTextInput, updateSubjectTextInput] = React.useState('');
    const [dairyTextInput, updateDairyTextInput] = React.useState('');

    // floating button
    const actions =[
        {
            text: props.dairyItem ? 'Update':'Add',
            name: props.dairyItem ? 'update':'add',
            icon: <Icons style={{alignSelf:'center'}} color={'white'} name={'checkmark'} size={30}></Icons>,
            position: 1
        },
    ];

    React.useEffect(()=>{
      //  console.log('called');
       // console.log(props.dairyItem)

        if(props.dairyItem){
            updateSubjectTextInput(props.dairyItem.subject);
            updateDairyTextInput(props.dairyItem.description);
        }else{
            updateSubjectTextInput('');
            updateDairyTextInput('');
        }


    }, [props.dairyItem]);

    const onSaveOrUpdate=()=>{
        if (subjectTextInput==='' && dairyTextInput==='')
        {
            return ToastAndroid.show('Subject and Description is needed!', ToastAndroid.LONG)
        }

        const data = {
            id: props.dairyItem ? props.dairyItem.id : Math.random(),
            subject: subjectTextInput,
            description: dairyTextInput
        };
        // console.log(data);


        if(props.dairyItem){
            return props.onUpdate(data)
        }
        return props.onSave(data);
    };

        return (
            <ReactNativeModal style={{backgroundColor:'white', margin:0}}
                              onDismiss={props.onDismiss}
                              onBackButtonPress={props.onDismiss}
                              onBackdropPress={props.onDismiss}
                              isVisible={props.isVisible}
                              useNativeDriver={true}
            >
                <View>
                   <TextInput value={subjectTextInput}
                              allowFontScaling={false}
                              onChangeText={(val)=>updateSubjectTextInput(val)}
                              style={[styles.textInput, {borderBottomWidth:1, borderTopWidth:1}]}
                              placeholder={'Enter Subject'}/>

                   <KeyboardAvoidingView>
                       <TextInput value={dairyTextInput}
                                  allowFontScaling={false}
                                  onChangeText={(val)=>updateDairyTextInput(val)}
                                  multiline={true}
                                  scrollEnabled={true}
                                  style={[styles.textInput, {borderBottomWidth:1}]}
                                  placeholder={'Write here your notes or dairy...'}/>
                   </KeyboardAvoidingView>
                </View>

                <FloatingAction
                    actions={actions}
                    onPressItem={onSaveOrUpdate}
                />

            </ReactNativeModal>
        );
};

const styles = StyleSheet.create({
    textInput:{
        width:wp('100%')
    }
});

export default CreateOrEditDairyItem;

/*
onPressItem={()=>{
    const data = {subject: subjectTextInput, description: dairyTextInput}
    console.log(data);
    return props.onSave(data);
}}*/
