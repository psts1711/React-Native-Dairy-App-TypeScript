import * as React from 'react';
import {StyleSheet, TouchableOpacity, View, ViewStyle} from 'react-native'
import {Spacing} from "../styles/Global";
import CustomText from "./CustomText";
import moment from "moment";
import {PrimaryTheme} from "../styles/Themes";

export interface Props {
    timestamp: Date;
    containerStyle?: ViewStyle | ViewStyle[]
}

const DateNTime = (props:Props)=>{
    return (
        <View style={[{marginBottom: Spacing.extralarge.marginBottom}, props.containerStyle]}>
            <CustomText style={styles.dateNtimeText}>
                {moment(props.timestamp).format('MMMM DD , YYYY - ddd')}
            </CustomText>
            <CustomText style={styles.dateNtimeText}>
                {moment(props.timestamp).format('h:mm a')}
            </CustomText>
        </View>
    )
};

const styles =  StyleSheet.create({
    dateNtimeText:{
        color: PrimaryTheme.$PRIMARY_COLOR_LIGHT,
        fontWeight: 'bold',
        textAlign : 'justify'
    },

});

DateNTime.defaultProps = {};
export default DateNTime