import * as React from 'react';
import {Image, FlatList, TouchableOpacity, View} from "react-native";
import ImageGallery from "./Modal/ImageGallery";
import {widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Icon from "./Icon";
import ImageItem from "./ImageItem";

export interface Props {
    images: any[];
    onImageDelete: any
}

const ImageList = (props: Props) => {

    const renderItem = (data) => {
       // console.log(data);
        return <ImageItem onImageDelete={()=>props.onImageDelete(data.item)} image={data.item}/>
    };

    return <FlatList
        keyExtractor={(data, index)=>index.toString()}
        numColumns={2}
        data={props.images}
        renderItem={renderItem} />
};

ImageList.defaultProps = {};
export default ImageList;