import * as React from 'react';
import {View, Image, StyleSheet, TouchableOpacity} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from "react-native-responsive-screen";
import CustomText from "./CustomText";
import {Utils} from "../utils/Utils";
import {PrimaryTheme} from "../styles/Themes";
import {Spacing} from "../styles/Global";
import {DairyItem as dairyItem} from "../models/DairyItem";
import moment from "moment";
import DateNTime from "./DateNTime";

export interface Props {
    dairyItem: dairyItem;
    onPress: any;
    //index: number;
}

const DairyItem = (props: Props) =>{

    return (

        <TouchableOpacity onPress={props.onPress} activeOpacity={0.5}
                          style={{marginBottom: Spacing.regular.marginBottom, padding:15}} /*key={props.index}*/>

           {/* <View style={{marginBottom: Spacing.extralarge.marginBottom}}>
                <CustomText style={styles.dateNtimeText}>
                    {moment(props.dairyItem.timestamp).format('MMMM DD , YYYY - ddd')}
                </CustomText>
                <CustomText style={styles.dateNtimeText}>
                    {moment(props.dairyItem.timestamp).format('h:mm a')}
                </CustomText>
            </View>*/}

            <DateNTime timestamp={props.dairyItem.timestamp}/>

            <View style={{flexDirection:"row"}}>
              <View style={{width:wp('70%'), marginRight: Spacing.extralarge.marginRight}}>

                  <CustomText style={styles.heading}>
                      {props.dairyItem.subject}
                  </CustomText>

                  <CustomText style={styles.description}>
                      {props.dairyItem.description}
                  </CustomText>
              </View>

                <Image
                   // resizeMethod={"auto"}
                   // resizeMode={'center'}
                    style={{width: wp('20%'), borderRadius:5,
                        height: hp('10%')}}
                    source={Utils.images.DAIRY_THUMBNAIL}
                    // source={{uri:'https://homepages.cae.wisc.edu/~ece533/images/airplane.png'}}
                    /* source={require('../assets/images/img101.png')} */ />
            </View>

        </TouchableOpacity>
    )
}

const styles =  StyleSheet.create({
    heading:{
        color: PrimaryTheme.$ACCENT_COLOR,
        fontWeight: 'bold',
        textAlign : 'justify'
    },
    dateNtimeText:{
        color: PrimaryTheme.$PRIMARY_COLOR_LIGHT,
        fontWeight: 'bold',
        textAlign : 'justify'
    },
    description:{
        color: PrimaryTheme.$TEXT_COLOR_500,
        fontWeight: '500',
        textAlign : 'justify',
        marginRight: Spacing.extralarge.marginRight
    }
});

export default DairyItem;