import * as React from 'react';
import {View, Text, StyleSheet, TextStyle} from 'react-native';
import {Typography} from "../styles/Global";

export interface Props{
    children: any;
    style?: TextStyle | TextStyle[],
    numberOfLines?: number
}

const CustomText = (props: Props) =>{
    return (
        <Text numberOfLines={props.numberOfLines} allowFontScaling={false} style={[style.text, props.style]}>{props.children}</Text>
    )
};
const style = StyleSheet.create({
    text:{
        ...Typography.paragraph,
    }
})

CustomText.defaultProps={
    numberOfLines: 3
}

export default CustomText;