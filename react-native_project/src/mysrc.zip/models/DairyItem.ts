export interface DairyItem {
    id?: number;
    subject: string;
    description: string;
    timestamp: Date;
    images: any[];
}