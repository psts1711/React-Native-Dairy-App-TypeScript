import {StyleSheet} from "react-native";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from "react-native-responsive-screen";
import {PrimaryTheme} from "./Themes";

export const Typography : any= {
    title:{
        fontSize: wp('8.5%'),
        color: PrimaryTheme.$TEXT_COLOR_900,
      //  marginBottom: 10,
        fontWeight: 'bold',
        fontFamily: 'mulim'
    },
    heading:{
        fontSize: wp('5.5%'),
        color: PrimaryTheme.$TEXT_COLOR_900,
        fontWeight: 'bold',
        fontFamily: 'mulim'
    },
    subHeading:{
        fontSize: wp('5%'),
        color: PrimaryTheme.$TEXT_COLOR_700,
        fontWeight: '500',
        fontFamily: 'mulim'
    },
    paragraph:{
        fontSize: wp('3.7%'),
        color: PrimaryTheme.$TEXT_COLOR_500,
        fontFamily: 'mulim'
    },
    lightText:{
        fontSize: wp('3.2%'),
        color: PrimaryTheme.$TEXT_COLOR_300,
        fontFamily: 'mulim'
    },
    error:{
        fontSize: wp('3.7%'),
        color: PrimaryTheme.$ERROR_COLOR,
        fontFamily: 'mulim',
        marginBottom:5
    }
};

// this is object
export const Spacing = {
    tiny:{
        marginLeft: wp('0.25%'),
        marginRight: wp('0.25%'),
        marginTop: wp('0.25%'),
        marginBottom: wp('0.25%')
    },
    small:{
        marginLeft: wp('0.5%'),
        marginRight: wp('0.5%'),
        marginTop: wp('0.5%'),
        marginBottom: wp('0.5%')
    },
    regular:{
        marginLeft: wp('1%'),
        marginRight: wp('1%'),
        marginTop: wp('1%'),
        marginBottom: wp('1%')
    },
    large:{
        marginLeft: wp('1.5%'),
        marginRight: wp('1.5%'),
        marginTop: wp('1.5%'),
        marginBottom: wp('1.5%')
    },
    extralarge:{
        marginLeft: wp('2%'),
        marginRight: wp('2%'),
        marginTop: wp('2%'),
        marginBottom: wp('2%')
    }

};

export const pComponentStyle = {

    textInput:{
        width:wp('70%'),
        borderWidth:1,
        marginBottom:10
    },
    pageTitle:{
        fontSize: 36,
        marginBottom: 10,
        letterSpacing: 2,
        fontFamily: 'mulim',
        color: PrimaryTheme.$TEXT_COLOR_900
    }
}

export const lComponentStyle = {
    textInput:{
    ...pComponentStyle.textInput, width: wp('60%')
    }
}