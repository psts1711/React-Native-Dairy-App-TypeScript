import Axios from 'axios';
import {getEnvironmentVariable} from "../environment";
import {UserActions} from "../redux/actions/UserActions";
import {Http} from "./Http";


export class Api{

    // login
    static login(data){
       // console.log(data);
        return Http.post(getEnvironmentVariable().auth_url, data, {
            baseURL: null,
        });
    };

    static getDairyItems(){
        return Http.get('/dairy.json')
    }

    static addDairyItem(data){
        return Http.post('/dairy.json', data)
    }
}