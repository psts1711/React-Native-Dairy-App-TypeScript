import {DairyActions} from "../redux/actions/DairyActions";
import {Api} from "./Api";
import {DairyItem} from "../models/DairyItem";

export class Repository {

    static getDairyItems(status:{ loading: boolean, loaded: boolean}, force=false)
    {
        return async dispatch => {
            try {
                if(!status.loaded && !status.loading){
                    // agar reducer me data nhi aaya hai to reducer ko call karunga
                    dispatch(DairyActions.DairyListRequestAction());
                    const data = await Api.getDairyItems();
                    console.log(data);
                    const dairyItems : DairyItem[] = [];
                    for(let key in data){
                        dairyItems.push({...data[key], id: key})
                    }
                    console.log(dairyItems);
                    dispatch(DairyActions.DairyListSuccessAction(dairyItems));
                }else{
                    return ;
                }
            }catch (e) {
                dispatch(DairyActions.DairyListErrorOccurred());
                return Promise.reject(e);
            }
        }
    }

    static addDairyItem(data: DairyItem){
        return async dispatch=>{
            try {
                const id = await Api.addDairyItem(data);
                const dairyItem ={...data, id:id};
                dispatch(DairyActions.addDairyItemAction(data));
                return dairyItem;
            }catch (e) {
                Promise.reject(e)
            }
        }
    }
}