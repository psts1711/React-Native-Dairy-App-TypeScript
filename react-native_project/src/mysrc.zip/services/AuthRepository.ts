import {UserActions} from "../redux/actions/UserActions";
import {Api} from "./Api";
import {AsyncStorageService} from "./AsyncStorageService";
import {User} from "../models/User";

export class AuthRepository {
    static login(data:{email:string, password: string, returnSecureToken: boolean})
    {
       //console.log(data);
        return async dispatch=>{
            try {
                dispatch(UserActions.LoginRequestAction());
                const user: User = await Api.login(data);
               // console.log(user);
                dispatch(UserActions.LoginRequestSuccessAction(user));
                await AsyncStorageService.setUser({
                    email: user.email,
                    idToken: user.idToken
                });
              //console.log(user);
                return user;
            }catch (e) {
                dispatch(UserActions.UserErrorOccurred());
                return Promise.reject(e)
            }
        }
    }
}