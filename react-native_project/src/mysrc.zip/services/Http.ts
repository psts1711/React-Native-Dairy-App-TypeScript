import _axios, {AxiosRequestConfig} from 'axios';
import {getEnvironmentVariable} from "../environment";
import {ToastAndroid} from "react-native";
import {User} from "../models/User";
import {AsyncStorageService} from "./AsyncStorageService";

export class Http {

    private static getToken=async()=>{
        const user:User = await AsyncStorageService.getUser();
        return user ? user.idToken : null;
    };

    private static axiox = _axios.create({
        baseURL: getEnvironmentVariable().base_api_url,
        headers: {
            "Content-Type": "application/json"
        },
    });

    static async get(url, config?:AxiosRequestConfig){
        //Http.get(url, config)
        try {
            const token = await Http.getToken();
            const customToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6InRCME0yQSJ9.eyJpc3MiOiJodHRwczovL2lkZW50aXR5dG9vbGtpdC5nb29nbGUuY29tLyIsImF1ZCI6InJlYWN0LW5hdGl2ZS1jb3Vyc2UtNDkyMTEiLCJpYXQiOjE2MjAyOTAzMTIsImV4cCI6MTYyMTQ5OTkxMiwidXNlcl9pZCI6IkQ4UDZKZloxbHdkMW9zRXoxZU9QcFlXczFoeTIiLCJlbWFpbCI6InRlc3RAZ21haWwuY29tIiwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIiwidmVyaWZpZWQiOmZhbHNlfQ.lVPrcqcdoEKQ72xYrm6oqdiXQyu_UWMUO9DFlKRaUZVtM6raVHe6spB0qJGEa_Dtho2RVp_YhlrQXZ51KjXH4mWE-A4Lb-dhEx3IVFKC1nDTraWnFznDo0AFj8pKzcu_zQcEktnfgDjol7r56-DbTcnH-LeHn5biTOlasZyTbImHOa-9HMM4lDNmN-FQWNfTmOGLY3RFj36ZrYoGfPA6hkTP9wMi4qSFC3I1NxU64bBEyUm0koYmnfiMIjJZaZYUQqdVGeCuJgbjgmqMfKUq7aMUF02nJ-C4nOXPK9duzEbRiDhYS0p238wHW1Ct-WitJbSU7t3movmXGxh5NKAEQw';

            const latestURL = token ? url + 'auth='+customToken : url;
          //  const token = await Http.getToken();
           // const header = token ? {Authorization: 'Bearer ' + token} : {};
           // const updatedConfig = {...config, header};

            const response = await Http.axiox.get(latestURL, config);
            if(response){
                return response.data;
            }
        }catch (e) {
            Http.handleErrors(e);
           // console.log(e);
            return Promise.reject(e);
        }
    }

    static async post(url, body?:object, config?:AxiosRequestConfig){
        try {
           const token = await Http.getToken();
           const customToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6InRCME0yQSJ9.eyJpc3MiOiJodHRwczovL2lkZW50aXR5dG9vbGtpdC5nb29nbGUuY29tLyIsImF1ZCI6InJlYWN0LW5hdGl2ZS1jb3Vyc2UtNDkyMTEiLCJpYXQiOjE2MjAyOTAzMTIsImV4cCI6MTYyMTQ5OTkxMiwidXNlcl9pZCI6IkQ4UDZKZloxbHdkMW9zRXoxZU9QcFlXczFoeTIiLCJlbWFpbCI6InRlc3RAZ21haWwuY29tIiwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIiwidmVyaWZpZWQiOmZhbHNlfQ.lVPrcqcdoEKQ72xYrm6oqdiXQyu_UWMUO9DFlKRaUZVtM6raVHe6spB0qJGEa_Dtho2RVp_YhlrQXZ51KjXH4mWE-A4Lb-dhEx3IVFKC1nDTraWnFznDo0AFj8pKzcu_zQcEktnfgDjol7r56-DbTcnH-LeHn5biTOlasZyTbImHOa-9HMM4lDNmN-FQWNfTmOGLY3RFj36ZrYoGfPA6hkTP9wMi4qSFC3I1NxU64bBEyUm0koYmnfiMIjJZaZYUQqdVGeCuJgbjgmqMfKUq7aMUF02nJ-C4nOXPK9duzEbRiDhYS0p238wHW1Ct-WitJbSU7t3movmXGxh5NKAEQw';
            const latestURL = token ? url + 'auth='+customToken : url;
          //  const header = token ? {Authorization: 'Bearer ' + token} : {};
           // const updatedConfig = {...config, header};


            const response = await Http.axiox.post(latestURL, body, config);
            if(response){
                return response.data;
            }
        }catch (e) {
            Http.handleErrors(e);
          //  console.log(e);
            return Promise.reject(e);
        }
    }

    private static handleErrors(error){
        if(error.response){
            const message = error.response.data.message;
            const errorMessage = message ? message : 'Something went wrong! Please try again';
            ToastAndroid.show(errorMessage, ToastAndroid.LONG);
        }else{
            ToastAndroid.show('Something went wrong! Please try again', ToastAndroid.LONG);
        }
    }

}
