import {NavigationContainer} from "@react-navigation/native";
import {appStack, authStack} from "./Routes";
import * as React from 'react';

export const Navigator = () =>{
  return (
      <NavigationContainer>
          {authStack()}
      </NavigationContainer>
  )
};