import {createStackNavigator} from '@react-navigation/stack';
import Login from "../../screens/Login";
import * as React from 'react';
import Dashboard from "../../screens/Dashboard";
import {PrimaryTheme} from "../../styles/Themes";
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import ViewDairyItem from "../../screens/ViewDairyItem";
import EditOrAddItem from "../../screens/EditOrAddItem";

const stack = createStackNavigator();

export enum ScreenNames{
    LOGIN = 'Login',
    DASHBOARD = 'Dashboard',
    VIEW_DAIRY_ITEM = 'View dairy item',
    EDIT_ADD_DAIRY_ITEM = 'Edit or Add dairy item'

}


export const authStack=()=>{
    return (
        <stack.Navigator initialRouteName={'Login'}>
            <stack.Screen name={ScreenNames.LOGIN} component={Login} />
            <stack.Screen name={'Signup'} component={Login}  />
        </stack.Navigator>
    )
};

export const appStack = ()=>{
    return(

        <stack.Navigator initialRouteName={ScreenNames.DASHBOARD} screenOptions={{
            headerStyle:{
            backgroundColor: PrimaryTheme.$PRIMARY_COLOR,
                height: hp('7.5%')
            },
            headerTitleStyle:{
                color:'white'
            },
            title:'My Dairy'
        }}>
            <stack.Screen name={ScreenNames.DASHBOARD} component={Dashboard} />

            <stack.Screen options={({route}) => {
                return {
                    title: (route.params as any).dairyItem.subject,
                    headerTintColor: 'white',
                };
            }} name={ScreenNames.VIEW_DAIRY_ITEM} component={ViewDairyItem} />


            <stack.Screen options={({route}) => {
                return {
                    title: (route.params as any).dairyItem ? 'Edit' : 'Add',
                    headerTintColor: 'white',
                };
            }} name={ScreenNames.EDIT_ADD_DAIRY_ITEM} component={EditOrAddItem} />

        </stack.Navigator>
    )
};