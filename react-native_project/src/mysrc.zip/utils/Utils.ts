import {ImageStyle, Platform, TextStyle, ViewStyle} from "react-native";

export class Utils {
    static dynamicStyles (
        potraitStyle: ViewStyle | ViewStyle[] | TextStyle | TextStyle[] | ImageStyle | ImageStyle[],
        landScapeStyle:ViewStyle | ViewStyle[] | TextStyle | TextStyle[] | ImageStyle | ImageStyle[],
        orientation: string){
        return orientation === "potrait" ? potraitStyle : landScapeStyle
    }

    static isiOS(){
        return Platform.OS === 'ios'
    }

    static images = {
        DAIRY_THUMBNAIL : require('../assets/images/img101.png'),
        ADD_IMAGE : require('../assets/fonts/add-image.png')
    }
}