import {DairyItem} from "../../models/DairyItem";

export enum DairyActionsTypes{
    ADD_DAIRY_ITEM = 'Add dairy item',
    UPDATE_DAIRY_ITEM = 'Update dairy item',
    DELETE_DAIRY_ITEM = 'Delte dairy item',

    //firebase action
    REQUEST_DAIRY_LISTS = 'Request Dairy Lists',
    DAIRY_LISTS_SUCCESS = 'Dairy Lists Success',
    DAIRY_ERROR = 'Dairy Error Occurred',


};

export class DairyActions{
    // two method below

    static addDairyItemAction = (dairyItem: DairyItem) => ({
            type: DairyActionsTypes.ADD_DAIRY_ITEM,
            payload: dairyItem
    });

    static updateDairyItemAction = (dairyItem: DairyItem) => ({
            type: DairyActionsTypes.UPDATE_DAIRY_ITEM,
            payload: dairyItem
    });

    static deleteDairyItemAction = (id:number) => {
        return {
            type: DairyActionsTypes.DELETE_DAIRY_ITEM,
            payload: id
        };
    };

    // firebase action
    static DairyListRequestAction = () => {
        return {
            type: DairyActionsTypes.REQUEST_DAIRY_LISTS,
        };
    };

    static DairyListSuccessAction = (dairyList: DairyItem[]) => {
        return {
            type: DairyActionsTypes.DAIRY_LISTS_SUCCESS,
            payload: dairyList
        };
    };

    static DairyListErrorOccurred = () => {
        return {
            type: DairyActionsTypes.DAIRY_ERROR,
        };
    };
}