import {User} from "../../models/User";

export enum UserActionsTypes {
    LOGIN_REQUEST = 'Login Request',
    LOGIN_REQUEST_SUCCESS = 'Login Request Success',
    USER_ERROR_OCCURRED = 'User Error Occurred',
    USER_LOGOUT = 'User Logout',
    
}

export class UserActions {
    static LoginRequestAction = () => ({
        type: UserActionsTypes.LOGIN_REQUEST
    });

    static LoginRequestSuccessAction = (user:User) => ({
        type: UserActionsTypes.LOGIN_REQUEST_SUCCESS,
        payload: user
    });

    static UserErrorOccurred = () => ({
        type: UserActionsTypes.USER_ERROR_OCCURRED,
    });

    static UserLogoutAction = () => ({
        type: UserActionsTypes.USER_LOGOUT,
    });


}