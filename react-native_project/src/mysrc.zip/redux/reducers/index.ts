import {combineReducers, createStore, compose, applyMiddleware } from 'redux';
import {DairyReducer, DairyReducerState} from "./DairyReducer";
import {UserReducer, UserReducerState} from "./UserReducer";
import thunk from 'redux-thunk';

export interface rootReducerState {
    dairyReducer: DairyReducerState;
    userReducer: UserReducerState;
}

export const rootReducer = combineReducers({
    // You can add multiple reducers here
    dairyReducer: DairyReducer,
    userReducer: UserReducer
});

let composeEnhancer = compose;
if(__DEV__){
    composeEnhancer = (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
}

export default createStore(rootReducer, composeEnhancer(applyMiddleware(thunk)));