import {UserActionsTypes} from "../actions/UserActions";
import {User} from "../../models/User";

export interface UserReducerState {
    user: User;
    loggedIn: boolean;
    loggingIn: boolean;
}

const initialState : UserReducerState= {
    user: null,
    loggedIn: false,
    loggingIn: false,
};

export const UserReducer = (state = initialState, action):UserReducerState => {
    switch (action.type) {
        case UserActionsTypes.LOGIN_REQUEST:{
            return {...state, loggingIn:true}
        }
        case UserActionsTypes.LOGIN_REQUEST_SUCCESS:{
            return {...state, loggingIn:false, loggedIn: true, user: action.payload}
        }
        case UserActionsTypes.USER_ERROR_OCCURRED:{
            return {...initialState}
        }
        case UserActionsTypes.USER_LOGOUT:{
            return {...initialState}
        }
        default:{
            return state;
        }
    }
};