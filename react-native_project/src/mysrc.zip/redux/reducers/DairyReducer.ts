import {DairyActions, DairyActionsTypes} from "../actions/DairyActions";
import {DairyItem} from "../../models/DairyItem";
import {UserActionsTypes} from "../actions/UserActions";

export interface DairyReducerState {
    dairyItems : DairyItem[];
    loading: boolean;
    loaded: boolean;
}

const initialState : DairyReducerState= {
    dairyItems : [],
    loading: false,
    loaded: false,
};

export const DairyReducer = (state = initialState, action):DairyReducerState => {
    switch (action.type) {

        case DairyActionsTypes.REQUEST_DAIRY_LISTS:{
            return {...state, loading: true}
        }
        case DairyActionsTypes.DAIRY_LISTS_SUCCESS:{
            return {...state, dairyItems: action.payload, loading: false, loaded: true}
        }
        case DairyActionsTypes.DAIRY_ERROR:{
            return {...initialState}
        }

        case DairyActionsTypes.ADD_DAIRY_ITEM:{
           // const  dairyItems = state.dairyItems;
           // dairyItems.push(action.payload);
           // return  {...state, dairyItems}            you can use also in typescript for same field

            const  dairyItems = state.dairyItems.concat(action.payload);
            return  {...state, dairyItems: dairyItems};
        }
        case DairyActionsTypes.UPDATE_DAIRY_ITEM:{
            //const dairyItems = state.dairyItems;
            const filterItems = state.dairyItems.filter(data=>data.id !== action.payload.id);
            filterItems.push(action.payload);
            return {...state, dairyItems: filterItems};
        }
        case DairyActionsTypes.DELETE_DAIRY_ITEM:{
            const dairyItems = state.dairyItems;
            const filterItems = dairyItems.filter(data=>data.id !== action.payload);
            return {...state, dairyItems: filterItems};
        }
        case UserActionsTypes.USER_LOGOUT: {
            return {...initialState}
        }

        default: {
            return state;
        }
    }
};