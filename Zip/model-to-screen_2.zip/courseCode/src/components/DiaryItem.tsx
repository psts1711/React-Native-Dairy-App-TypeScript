import * as React from 'react';
import {Image, StyleSheet, View, TouchableOpacity} from 'react-native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import CustomText from './CustomText';
import {PrimaryTheme} from '../styles/Themes';
import {Utils} from '../utils/utils';
import {Spacing} from '../styles/Global';
import {DiaryItem as diaryItem} from "../models/DiaryItem";

export interface Props {
  diaryItem: diaryItem;
  onPress: any;
}

const DiaryItem = (props: Props) => {
  return (
    <TouchableOpacity onPress={props.onPress}
      activeOpacity={0.6}
      style={{marginBottom: Spacing.regular.marginBottom, padding: 15}}>
      {/*// date and time view (this is comment out code)*/}
      <View style={{marginBottom: Spacing.large.marginBottom}}>
        <CustomText style={styles.dateNTimeText}>
          {props.diaryItem.date}
        </CustomText>
        <CustomText style={styles.dateNTimeText}>
          {props.diaryItem.time}
        </CustomText>
      </View>
      {/*// row view (this is comment out code)*/}
      <View style={{flexDirection: 'row'}}>
        {/*// subject and description view (this is comment out code)*/}
        <View
          style={{
            width: wp('70%'),
            marginRight: Spacing.extraLarge.marginRight,
          }}>
          <CustomText
            style={{color: PrimaryTheme.$ACCENT_COLOR, fontWeight: 'bold'}}>
            {props.diaryItem.subject}
          </CustomText>
          <CustomText style={{marginRight: Spacing.extraLarge.marginRight}}>
            {props.diaryItem.description}
          </CustomText>
        </View>
        {/*// Our image (this is comment out code)*/}
        <Image
          style={{height: hp('10%'), borderRadius: 5, width: wp('22%')}}
          source={Utils.images.DIARY_THUMBNAIL}
        />
      </View>
    </TouchableOpacity>
  );
};
DiaryItem.defaultProps = {};

const styles = StyleSheet.create({
  dateNTimeText: {color: PrimaryTheme.$DARK_PRIMARY_COLOR, fontWeight: 'bold'},
});
export default DiaryItem;
