import * as React from 'react';
import Container from '../components/Container';
import DiaryList from '../components/DiaryList';
import CustomText from '../components/CustomText';
import If from '../components/If';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {FloatingAction} from 'react-native-floating-action';
import Icon from '../components/Icon';
import {ActionSheetCustom as ActionSheet} from 'react-native-actionsheet';
import {DiaryItem} from '../models/DiaryItem';
import {ScreenNames} from '../utils/navigations/Routes';

interface Props {
  route: any;
  navigation: any;
}

interface State {
  diaryItems: DiaryItem[];
  selectedItem: DiaryItem;
}

enum ActionTypes {
  VIEW,
  'Edit',
  'Delete',
  'Cancel',
}
class Dashboard extends React.Component<Props, State> {
  private actionSheetRef: any;
  constructor(props) {
    super(props);
    this.state = {
      diaryItems: [
        {
          id: 0,
          subject: 'my subject 1',
          date: 'March 28, 2020 - Sat',
          time: '3:12 am',
          description:
            'Today was one of my best day of life.Today was one of my best day of life. Today was one of my best day of life.  ',
        },
        {
          id: 1,
          subject: 'my subject 2',
          date: 'March 28, 2020 - Sat',
          time: '3:12 am',
          description:
            'Today was one of my best day of life.Today was one of my best day of life. Today was one of my best day of life.  ',
        },
      ],
      selectedItem: null,
    };
  }
  actions = [
    {
      text: 'Add',
      name: 'add',
      icon: <Icon name={'add'} />,
      position: 1,
    },
  ];

  handleActionButton = index => {
    switch (index) {
      case ActionTypes.Cancel: {
        this.setState({selectedItem: null});
        break;
      }
      case ActionTypes.Edit: {
        this.onAddOrUpdate();
        break;
      }
      case ActionTypes.VIEW: {
        this.onView();
        break;
      }
      case ActionTypes.Delete: {
        this.onDelete();
      }
    }
  };

  onAddOrUpdate() {
    this.props.navigation.navigate(ScreenNames.EDIT_ADD_DIARY_ITEM, {
      diaryItem: this.state.selectedItem,
    });
    this.setState({selectedItem: null});
  }
  onDelete() {
    const filteredItems = this.deleteItemAndGetItems(this.state.selectedItem);
    this.setState({diaryItems: filteredItems, selectedItem: null});
  }

  deleteItemAndGetItems(item): DiaryItem[] {
    const diaryItems = this.state.diaryItems;
    return diaryItems.filter(data => data.id !== item.id);
  }
  onView() {
    this.props.navigation.navigate(ScreenNames.VIEW_DIARY_ITEM, {
      diaryItem: this.state.selectedItem,
    });
    this.setState({selectedItem: null});
  }
  render() {
    return (
      <Container
        containerStyles={{
          justifyContent: 'flex-start',
        }}>
        <If show={!!this.state.diaryItems.length}>
          <DiaryList
            onPress={val => {
              this.setState({selectedItem: val});
              this.actionSheetRef.show();
            }}
            diaryItems={this.state.diaryItems}
          />
        </If>
        <If show={!this.state.diaryItems.length}>
          <CustomText style={{width: wp('95%'), textAlign: 'center'}}>
            Currently, No Item is added. Please start adding Items
          </CustomText>
        </If>
        <FloatingAction
          actions={this.actions}
          onPressItem={name => {
            this.onAddOrUpdate();
          }}
        />
        <ActionSheet
          ref={ref => (this.actionSheetRef = ref)}
          title={
            <CustomText style={{color: '#000', fontSize: 18}}>
              Which one do you like?
            </CustomText>
          }
          options={['View', 'Edit', 'Delete', 'Cancel']}
          cancelButtonIndex={3}
          destructiveButtonIndex={2}
          onPress={this.handleActionButton}
        />
      </Container>
    );
  }
  componentDidMount(): void {}
}

export default Dashboard;
