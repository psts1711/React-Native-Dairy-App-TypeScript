module.exports = {
  dependencies: {
    'react-native-vector-icons': {
      platforms: {
        android: null,
        ios: null,
      },
    },
  },
  assets: ['./src/assets/fonts/'],
};
