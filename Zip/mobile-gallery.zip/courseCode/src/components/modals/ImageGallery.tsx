import * as React from 'react';
import {FlatList, Image, TouchableOpacity, View} from 'react-native';
import ReactNativeModal from 'react-native-modal';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {Utils} from '../../utils/utils';
import Icon from '../Icon';
export interface Props {
  isVisible: boolean;
  onDismiss: any;
}

const data = [
  Utils.images.DIARY_THUMBNAIL,
  Utils.images.DIARY_THUMBNAIL,
  Utils.images.DIARY_THUMBNAIL,
  Utils.images.DIARY_THUMBNAIL,
  Utils.images.DIARY_THUMBNAIL,
  Utils.images.DIARY_THUMBNAIL,
];
const ImageGallery = (props: Props) => {
  return (
    <ReactNativeModal
      isVisible={props.isVisible}
      onBackButtonPress={props.onDismiss}
      onBackdropPress={props.onDismiss}
      onDismiss={props.onDismiss}>
      <View
        style={{
          height: hp('40%'),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <TouchableOpacity>
          <Image
            style={{height: hp('20%'), width: wp('80%')}}
            source={Utils.images.ADD_IMAGE}
          />
        </TouchableOpacity>
        <FlatList
          numColumns={2}
          data={data}
          renderItem={data => {
            return (
              <View style={{margin:2}}>
                <Image
                  style={{height: hp('20%'), width: wp('40%')}}
                  source={data.item}
                />
                <TouchableOpacity style={{position: 'absolute',alignSelf:'flex-end'}}>
                  <Icon name={'remove-circle'} color={'red'} />
                </TouchableOpacity>
              </View>
            );
          }}
        />
      </View>
    </ReactNativeModal>
  );
};
ImageGallery.defaultProps = {};
export default ImageGallery;
