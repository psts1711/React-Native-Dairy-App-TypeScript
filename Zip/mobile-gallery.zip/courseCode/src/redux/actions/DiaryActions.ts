import {DiaryItem} from '../../models/DiaryItem';

export enum DiaryActionTypes {
  ADD_DIARY_ITEM = 'Add diary Item',
  UPDATE_DIARY_ITEM = 'update diary Item',
  DELETE_DIARY_ITEM = 'delete diary Item',
}

export class DiaryActions {
  static AddDiaryItemAction = (diaryItem:DiaryItem) => {
    return {
      type: DiaryActionTypes.ADD_DIARY_ITEM,
        payload: diaryItem,
    };
  };
  static UpdateDiaryItemAction = (diaryItem: DiaryItem) => {
    return {
      type: DiaryActionTypes.UPDATE_DIARY_ITEM,
      payload: diaryItem,
    };
  };

  static DeleteDiaryItemAction = (id: number) => {
    return {
      type: DiaryActionTypes.DELETE_DIARY_ITEM,
      payload: id,
    };
  };
}
