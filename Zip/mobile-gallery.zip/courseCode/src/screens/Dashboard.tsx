import * as React from 'react';
import Container from '../components/Container';
import DiaryList from '../components/DiaryList';
import CustomText from '../components/CustomText';
import If from '../components/If';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import {FloatingAction} from 'react-native-floating-action';
import Icon from '../components/Icon';
import {ActionSheetCustom as ActionSheet} from 'react-native-actionsheet';
import {DiaryItem} from '../models/DiaryItem';
import {ScreenNames} from '../utils/navigations/Routes';
import {connect} from 'react-redux';
import {DiaryActions} from '../redux/actions/DiaryActions';
interface Props {
  route: any;
  navigation: any;
  diaryItems: DiaryItem[];
  onDelete: any;
}

interface State {
  selectedItem: DiaryItem;
}

enum ActionTypes {
  VIEW,
  'Edit',
  'Delete',
  'Cancel',
}
class Dashboard extends React.Component<Props, State> {
  private actionSheetRef: any;
  constructor(props) {
    super(props);
    this.state = {
      selectedItem: null,
    };
  }
  actions = [
    {
      text: 'Add',
      name: 'add',
      icon: <Icon name={'add'} />,
      position: 1,
    },
  ];

  handleActionButton = index => {
    switch (index) {
      case ActionTypes.Cancel: {
        this.setState({selectedItem: null});
        break;
      }
      case ActionTypes.Edit: {
        this.onAddOrUpdate();
        break;
      }
      case ActionTypes.VIEW: {
        this.onView();
        break;
      }
      case ActionTypes.Delete: {
        this.onDelete();
      }
    }
  };

  onAddOrUpdate() {
    this.props.navigation.navigate(ScreenNames.EDIT_ADD_DIARY_ITEM, {
      diaryItem: this.state.selectedItem,
    });
    this.setState({selectedItem: null});
  }
  onDelete() {
    this.props.onDelete(this.state.selectedItem.id);
    this.setState({selectedItem: null});
  }

  onView() {
    this.props.navigation.navigate(ScreenNames.VIEW_DIARY_ITEM, {
      diaryItem: this.state.selectedItem,
    });
    this.setState({selectedItem: null});
  }
  render() {
    console.log('called dashboard render');
    return (
      <Container
        containerStyles={{
          justifyContent: 'flex-start',
        }}>
        <If show={!!this.props.diaryItems.length}>
          <DiaryList
            onPress={val => {
              this.setState({selectedItem: val});
              this.actionSheetRef.show();
            }}
            diaryItems={this.props.diaryItems}
          />
        </If>
        <If show={!this.props.diaryItems.length}>
          <CustomText style={{width: wp('95%'), textAlign: 'center'}}>
            Currently, No Item is added. Please start adding Items
          </CustomText>
        </If>
        <FloatingAction
          actions={this.actions}
          onPressItem={name => {
            this.onAddOrUpdate();
          }}
        />
        <ActionSheet
          ref={ref => (this.actionSheetRef = ref)}
          title={
            <CustomText style={{color: '#000', fontSize: 18}}>
              Which one do you like?
            </CustomText>
          }
          options={['View', 'Edit', 'Delete', 'Cancel']}
          cancelButtonIndex={3}
          destructiveButtonIndex={2}
          onPress={this.handleActionButton}
        />
      </Container>
    );
  }
  componentDidMount(): void {}
}
const mapStateToProps = state => {
  return {
    diaryItems: state.diaryReducer.diaryItems,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onDelete: id => dispatch(DiaryActions.DeleteDiaryItemAction(id)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Dashboard);
