export interface DiaryItem {
  id?: number;
  subject: string;
  description: string;
  timeStamp: Date;
  images: [];
}
