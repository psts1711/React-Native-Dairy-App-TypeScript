import {Environment} from './index';

export const DevEnvironment: Environment = {
  base_api_url: 'https://react-native-course-d2aef.firebaseio.com',
  auth_url:
    'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCY4d659-iaTD6bDO-rD7qhODuFk1wLgJg',
};
