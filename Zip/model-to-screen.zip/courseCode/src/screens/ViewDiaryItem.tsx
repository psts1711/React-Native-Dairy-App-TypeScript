import * as React from 'react';
import {View} from 'react-native';
import Container from '../components/Container';
import CustomText from '../components/CustomText';
import {Spacing} from '../styles/Global';

interface Props {
  route: any;
}

interface State {}

class ViewDiaryItem extends React.Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <Container
        containerStyles={{
          justifyContent: 'flex-start',
          marginTop: Spacing.extraLarge.marginTop,
        }}>
        <CustomText style={{marginBottom: Spacing.large.marginBottom}}>
          {this.props.route.params.diaryItem.subject}
        </CustomText>
        <CustomText>{this.props.route.params.diaryItem.description}</CustomText>
      </Container>
    );
  }

  componentDidMount(): void {}
}

export default ViewDiaryItem;
