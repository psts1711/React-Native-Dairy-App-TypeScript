import 'react-native-gesture-handler';
import * as React from 'react';
import {StyleSheet, TextInput, View} from 'react-native';
import {Formik} from 'formik';
import {
  heightPercentageToDP as hp,
  listenOrientationChange,
  removeOrientationListener,
} from 'react-native-responsive-screen';

import If from '../components/If';
import {lComponentStyles, pComponentStyles, Typography} from '../styles/Global';
import CustomText from '../components/CustomText';
import Container from '../components/Container';
import {Validators} from '../utils/validators';
import {Utils} from '../utils/utils';
import CustomButton from '../components/CustomButton';

interface State {
  form: {
    emailTextInput: string;
    passwordTextInput: string;
  };
  orientation: string;
}

interface Props {}
class Login extends React.Component<Props, State> {
  private passwordInputRef;
  constructor(props) {
    super(props);
    this.state = {
      form: {
        emailTextInput: '',
        passwordTextInput: '',
      },
      orientation: 'portrait',
    };
  }

  componentDidMount(): void {
    listenOrientationChange(this);
  }
  componentWillUnmount(): void {
    removeOrientationListener();
  }

  render() {
    return (
      <Container containerStyles={{alignItems: 'center'}}>
        <CustomText
          style={[
            Typography.title,
            {letterSpacing: 5, marginBottom: hp('2%')},
          ]}>
          Login
        </CustomText>
        <Formik
          initialValues={this.state.form}
          validateOnMount={true}
          validateOnChange={true}
          onSubmit={() => {
            console.log('on submit');
          }}
          validationSchema={Validators.loginValidator}>
          {props => {
            return (
              <View style={{alignItems: 'center'}}>
                <TextInput
                  onSubmitEditing={() => this.passwordInputRef.focus()}
                  returnKeyType={'next'}
                  onBlur={() => props.setFieldTouched('emailTextInput')}
                  onChangeText={props.handleChange('emailTextInput')}
                  style={Utils.dynamicStyles(
                    pComponentStyles.textInput,
                    lComponentStyles.textInput,
                    this.state.orientation,
                  )}
                  placeholder={'Email'}
                  value={props.values.emailTextInput}
                />
                <If show={props.dirty && props.touched.emailTextInput}>
                  <CustomText style={[Typography.errorText]}>
                    {props.errors.emailTextInput}
                  </CustomText>
                </If>
                <TextInput
                  onSubmitEditing={() => {
                    if (props.isValid) {
                      console.log('is valid');
                    } else {
                      console.log('form is not valid');
                    }
                  }}
                  onBlur={() => props.setFieldTouched('passwordTextInput')}
                  ref={ref => (this.passwordInputRef = ref)}
                  returnKeyType={'done'}
                  onChangeText={props.handleChange('passwordTextInput')}
                  style={Utils.dynamicStyles(
                    pComponentStyles.textInput,
                    lComponentStyles.textInput,
                    this.state.orientation,
                  )}
                  placeholder={'Password'}
                  value={props.values.passwordTextInput}
                />
                <If show={props.dirty && props.touched.passwordTextInput}>
                  <CustomText style={[Typography.errorText]}>
                    {props.errors.passwordTextInput}
                  </CustomText>
                </If>
                <CustomButton
                  useIcon={true}
                  iconName={'key'}
                  disabled={!props.isValid}
                  title={'Login'}
                  onPress={() => {
                    if (props.isValid) {
                      return props.handleSubmit();
                    } else {
                      console.log('form is not valid');
                    }
                  }}
                />
              </View>
            );
          }}
        </Formik>
      </Container>
    );
  }
}

const portraitStyles = () => {
  return StyleSheet.create({});
};

const landScapeStyles = () => {
  return StyleSheet.create({});
};

export default Login;
