import * as React from 'react';
import {StyleSheet, TextInput, View} from 'react-native';
import Container from '../components/Container';
import {FloatingAction} from 'react-native-floating-action';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import Icon from '../components/Icon';
import {DiaryItem} from '../models/DiaryItem';

interface Props {
  route: {params: {diaryItem: DiaryItem}};
}

interface State {
  subjectTextInput: string;
  descriptionTextInput: string;
}

class EditOrAddItem extends React.Component<Props, State> {
  private readonly diaryItem = this.props.route.params.diaryItem;
  constructor(props) {
    super(props);
    this.state = {
      subjectTextInput: this.diaryItem ? this.diaryItem.subject : '',
      descriptionTextInput: this.diaryItem ? this.diaryItem.description : '',
    };
  }
  actions = [
    {
      text: this.diaryItem ? 'Update' : 'Add',
      name: this.diaryItem ? 'update' : 'add',
      icon: <Icon name={'checkmark'} />,
      position: 1,
    },
  ];
  updateSubjectTextInput = val => {
    this.setState({subjectTextInput: val});
  };
  updateDescriptionTextInput = val => {
    this.setState({descriptionTextInput: val});
  };

  onSaveOrUpdate = () => {};
  render() {
    return (
      <Container>
        <View style={{flex: 1}}>
          <TextInput
            allowFontScaling={false}
            value={this.state.subjectTextInput}
            onChangeText={this.updateSubjectTextInput}
            style={[styles.textInput, {borderBottomWidth: 1}]}
            placeholder={'Enter Subject'}
          />
          <TextInput
            allowFontScaling={false}
            onChangeText={this.updateDescriptionTextInput}
            value={this.state.descriptionTextInput}
            multiline={true}
            scrollEnabled={true}
            style={styles.textInput}
            placeholder={'Start Writing your Diary...'}
          />
        </View>
        <FloatingAction
          actions={this.actions}
          onPressItem={this.onSaveOrUpdate}
        />
      </Container>
    );
  }

  componentDidMount(): void {}
}
const styles = StyleSheet.create({
  textInput: {
    width: wp('100%'),
    paddingBottom: 10,
  },
});
export default EditOrAddItem;
