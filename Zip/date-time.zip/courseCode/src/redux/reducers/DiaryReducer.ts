import {DiaryActionTypes} from '../actions/DiaryActions';
import {DiaryItem} from '../../models/DiaryItem';

interface DiaryReducerState {
  diaryItems: DiaryItem[];
}

const initialState: DiaryReducerState = {
  diaryItems: [
    {
      id: 0,
      subject: 'my subject 1',
      timeStamp: new Date(),
      description:
        'Today was one of my best day of life.Today was one of my best day of life. Today was one of my best day of life.  ',
    },
    {
      id: 1,
      subject: 'my subject 2',
      timeStamp: new Date(),
      description:
        'Today was one of my best day of life.Today was one of my best day of life. Today was one of my best day of life.  ',
    },
  ],
};

export const DiaryReducer = (
  state = initialState,
  action,
): DiaryReducerState => {
  switch (action.type) {
    case DiaryActionTypes.ADD_DIARY_ITEM: {
      const diaryItems = state.diaryItems.concat(action.payload);
      return {...state, diaryItems};
    }
    case DiaryActionTypes.UPDATE_DIARY_ITEM: {
      const filteredItems = state.diaryItems.filter(
        data => data.id !== action.payload.id,
      );
      filteredItems.push(action.payload);
      return {...state, diaryItems: filteredItems};
    }
    case DiaryActionTypes.DELETE_DIARY_ITEM: {
      const diaryItems = state.diaryItems;
      const filteredItems = diaryItems.filter(
        data => data.id !== action.payload,
      );
      return {...state, diaryItems: filteredItems};
    }
    default: {
      return state;
    }
  }
};
